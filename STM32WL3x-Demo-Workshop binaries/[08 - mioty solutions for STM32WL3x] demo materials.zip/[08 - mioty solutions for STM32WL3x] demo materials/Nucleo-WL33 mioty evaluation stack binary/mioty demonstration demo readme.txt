
## EP-Information

* After reset, all three user leds will blink multiple times to signalize the reset process
* Both Endpoints have the same functionality for button 1, i. e. sending an class Z uplink to the gateway with the 16 bit ADC value with the junction temperature
* The functionality of button 2 is described below in the individuel information section for each endpoint.

### EP - Binary 1

This Endpoint will turn on the user LED after the reception of the message described above. It will be lit as long as no button was pressed to start a new transmission, i. e. button 1 for uplink only or button 2 for uplink and downlink.

file-name: mioty_ep_device_stm32wl3_0001.hex
EUI: 57-4c-33-33-43-43-00-01
NWK: 00112233445566778899aabbccddeeff
Short-Address: 0001

### Additional Information

Please erase the flash completely before flashing any of the above binaries. Otherwise, previously configured and stored data from the previously flashed image will be present, e. g. short address, which will lead to a missed reception.